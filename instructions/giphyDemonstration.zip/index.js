const btn = document.querySelector('button');
const mainSection = document.querySelector('#mainSection');
const searchStringInput = document.querySelector('#searchStringInput');

btn.addEventListener('click', () => {
  // Go get a gif
  const searchString = searchStringInput.value;
  getGif(searchString);
});

function getGif(searchString = "ryan+gosling") {
  const url = `https://api.giphy.com/v1/gifs/search?q=${searchString}&rating=g&api_key=2ZNGpepX3FFiOFQANc90EEyOd88LyQhT&limit=5`;
  fetch(url)
  .then(res => res.json())
  .then(imageData => imageData.data)
  .then(arrayOfDetailedData => {
    mainSection.innerHTML="";
    for (let detailedData of arrayOfDetailedData) {
      console.log(detailedData);
      const imgsrc = detailedData.images.original.url;
      console.log(`The url we want is ${imgsrc}`);
      mainSection.innerHTML += `<img src="${imgsrc}" id="fetchedImage" />`;
    }
  })

}
console.log('index is loading');